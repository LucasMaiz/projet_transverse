<template>
  <div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <p> Quelle type de recherche voulez-vous faire ? </p>
    <button @click="byIngredients()">Search by ingredients </button>
    <button @click="byQuery()">Search by query </button>
    <button @click="byCountry()">Search by country </button>
    <div v-if="byIngreVar == 1">
      <label>Mettez la liste des ingrédients que vous avez séparés d'une virgule , </label>
      <input v-model="listIngredients">
      <button @click="testfunction(listIngredients)"> Print recipes </button>
    </div>
    <div v-if="byQueryVar == 1">
      <p> Please enter a plate </p>
    </div>
    <div v-if="byCountryVar == 1">
      <p> Please enter a country </p>
    </div>
    <button v-if="onglet_courant>0" @click="reset()"> Reset </button>
    <div v-if="onglet_courant==1"> 
      <button @click="sortByLikes(1)" v-if="listId.length > 0"> Trier par likes ordres croissant </button>
      <button @click="sortByLikes(-1)" v-if="listId.length > 0"> Trier par likes ordres décroissant </button>
      <div v-if="listId.length > 0">
        <p> {{onglet_courant}} / {{listId.length/5}} </p>
        <button @click="prec()">precedent</button>
        <button @click="suivant()">suivant</button>
      </div>
      <article v-for="article in recettesCourantes" :key="article.id_recipe">
        
        <p> NOM DE LA RECETTE : {{article.name_recipe}} </p>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        <p> INGREDIENTS MANQUANTS : </p>
        <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + kkk.img_ingredients + ')' }" ></div>
          </div>
          <p>{{kkk.name_ingredients}} </p>
          
        </article>

        <p> USED INGREDIENTS : </p>
        <article v-for="qqq in article.used_ingredients" :key="qqq.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + qqq.img_ingredients + ')' }" ></div>
          </div>
          <p>{{qqq.name_ingredients}} </p>
          
        </article>


        <p> <a v-bind:href="article.url" > Lien vers la recette </a> </p>
        <div v-for="diet in article.diets" :key="diet.id">
          <p> {{diet}} </p>
        </div>
        <p> {{article.likes}} </p>
      </article>
    </div>


    <div v-else> 
      <button @click="sortByLikes(1)" v-if="listId.length > 0"> Trier par likes ordres croissant </button>
      <button @click="sortByLikes(-1)" v-if="listId.length > 0"> Trier par likes ordres décroissant </button>
      <div v-if="listId.length > 0">
        <p> {{onglet_courant}} / {{listId.length/5}} </p>
        <button @click="prec()">precedent</button>
        <button @click="suivant()">suivant</button>
      </div>
      <article v-for="article in recettesCourantesbis" :key="article.id_recipe">
        
        <p> NOM DE LA RECETTE : {{article.name_recipe}} </p>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        <p> INGREDIENTS MANQUANTS : </p>
        <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + kkk.img_ingredients + ')' }" ></div>
          </div>
          <p>{{kkk.name_ingredients}} </p>
          
        </article>

        <p> USED INGREDIENTS : </p>
        <article v-for="qqq in article.used_ingredients" :key="qqq.id">
        

          <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + qqq.img_ingredients + ')' }" ></div>
          </div>
          <p>{{qqq.name_ingredients}} </p>
          
        </article>

        <p> <a v-bind:href="article.url" > Lien vers la recette </a> </p>
        <div v-for="diet in article.diets" :key="diet.id">
          <p> {{diet}} </p>
        </div>
        <p> {{article.likes}} </p>
      </article>
    </div>

    <div v-if="listId.length > 0">
      <p> {{onglet_courant}} / {{listId.length/5}} </p>
      <button @click="prec()">precedent</button>
      <button @click="suivant()">suivant</button>
    </div>
  </div>
</template>

<script>


module.exports = {
  props: {
    listId : { type: Array, default: []},
    recettesCourantes : { type: Array, default: []},
  },
  data () {
    return {
      editingId : 0,
      listIngredients : "",
      countMissedIngredients : 0,
      onglet_courant : 1,
      recettesCourantesbis : [],
      byIngreVar : 0,
      byQueryVar : 0,
      byCountryVar : 0
    }
  },
  async mounted () {
  },
  methods: {
    testfunction(ingredients){
      this.$emit('testfunction', ingredients)
      if(this.onglet_courant != 1){
        this.onglet_courant = 1
      }
    },
    itsTrue(id){
      if(this.editingId == id){
        return true;
      }
    },
    prec(){
      if(this.onglet_courant > 1){
        this.onglet_courant = this.onglet_courant - 1
        this.actualiser()
      }
    },
    suivant(){
      if(this.onglet_courant < this.listId.length/5){
        this.onglet_courant = this.onglet_courant + 1
        this.actualiser()
      }
    },
    actualiser(){

      if(this.onglet_courant != 1){
          this.recettesCourantesbis = []
          for(let i=(this.onglet_courant-1)*5; i<this.onglet_courant*5; i++){
            this.recettesCourantesbis.push(this.listId[i])
          }
        }
      },
      sortByLikes(x){
        if(this.onglet_courant != 1){
          this.onglet_courant = 1;
        }
        
        this.listId.sort(function compare(a, b) {
          if (a.likes < b.likes)
            return -x;
          if (a.likes > b.likes )
            return x;
          return 0;
        });
        this.$emit('changefirstpage')
        if(this.onglet_courant!=1){
          this.recettesCourantesbis = []
          for(let i=(this.onglet_courant-1)*5; i<this.onglet_courant*5; i++){
            this.recettesCourantesbis.push(this.listId[i])
          }
        }
      },
      reset(){
        this.onglet_courant = 0;
        this.recettesCourantesbis = []
        this.$emit('resetrecipes')
      },
      byIngredients(){
        if(this.byIngreVar == 0){
          this.byIngreVar = 1
        }
        if(this.byQueryVar == 1){
          this.byQueryVar = 0
        }
        if(this.byCountryVar == 1){
          this.byCountryVar = 0
        }
      },
      byQuery(){
        if(this.byIngreVar == 1){
          this.byIngreVar = 0
        }
        if(this.byQueryVar == 0){
          this.byQueryVar = 1
        }
        if(this.byCountryVar == 1){
          this.byCountryVar = 0
        }
      },
      byCountry(){
        if(this.byIngreVar == 1){
          this.byIngreVar = 0
        }
        if(this.byQueryVar == 1){
          this.byQueryVar = 0
        }
        if(this.byCountryVar == 0){
          this.byCountryVar = 1
        }
      },

  }
}
</script>

<style scoped>

  .recipe-img div {
    margin: 10px auto;
    width: 312px;
    height: 231px;
    background-size: cover;
  }

  .ingredient-img div{
    margin: 5px auto;
    width: 150px;
    height: 100px;
    background-size: cover;
  }
</style>