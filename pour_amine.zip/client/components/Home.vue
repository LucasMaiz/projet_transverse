<template>
  <div>
    <div class="header">
            <div class="container">
                <div class="cotegauche">
                    <h1>Hundreds of recipes according to your needs</h1>
                    <h2><img src="harvest.svg"> Thousands of recipes listed<br> <img src="food-tray.svg"> Share your favorite recipes<br> <img src="diet.svg"> Everything your body needs<br> <img src="cooking-time.svg"> Save time  <br> </h2>
                </div>

                <div class="cotedroit">
                    <form method="POST" action="" class="">
                        <div class="blocchoix">
                            <p>What is your objective?</p>
                            <select>
                                <option value>Objective</option>
                                <option value="1">Losing weight</option>
                                <option value="2">Strengthening the immune system</option>
                                <option value="3">Gain of energy</option>
                                <option value="3">Cooking quickly</option>



                            </select>
                            <input value="Search" class="btnrecherche">
                        </div>
                    </form>
                </div>
                
            </div>
            

        </div>
    <p class="typere"> What type of research do you want to do ? </p>
    <button class="btning" @click="byIngredients()">Search by ingredients </button>
    <button class="btnquery" @click="byQuery()">Search by query </button>
    <button class="btncountry" @click="byCountry()">Search by country </button>
    <div class="search_ingredients" v-if="byIngreVar == 1">
      <div>
        <label>Put the list of ingredients that you have separated by a comma , </label>
        <input class="searchbtn" v-model="listIngredients">
        <button class="btning2" @click="testfunction(listIngredients)"> Print recipes </button>
      </div>
    </div>
    <div v-if="byQueryVar == 1">
      <p> Please enter a plate </p>
    </div>
    <div v-if="byCountryVar == 1">
      <p> Please enter a country </p>
    </div>
    <button class="btnreset" v-if="onglet_courant>0" @click="reset()"> Reset </button>
    <div v-if="onglet_courant==1" class="proposition">
      <div class="affich_croisde">
          <button class="ordrecrois" @click="sortByLikes(1)" v-if="listId.length > 0"> Sort in ascending order </button>
          <button class="ordredecroi" @click="sortByLikes(-1)" v-if="listId.length > 0"> Sort in descending order </button>
      </div>
 
      <div v-if="listId.length > 0" class="next_prec">
        <p> {{onglet_courant}} / {{listId.length/5}} </p>
        <button @click="prec()">precedent</button>
        <button @click="suivant()">Next</button>
      </div>
      <article class="recettestyle" v-for="article in recettesCourantes" :key="article.id_recipe">
        <div class="headerrecette">
          <p class="titrere">RECIPE NAME : {{article.name_recipe}} </p>
          <p>  👍 {{ article.likes}} </p>
        </div>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        <div class="textrecette">
          <p> ❌ MISSING INGREDIENTS : </p>
          <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <!-- <div class="ingredient-img">
            <div :style="{ backgroundImage: 'url(' + kkk.img_ingredients + ')' }" ></div>
          </div> -->
            <p>•{{kkk.name_ingredients}} </p>
          
          </article>

          <p> ✅ USED INGREDIENTS : </p>
          <article v-for="qqq in article.used_ingredients" :key="qqq.id">
        

            <div class="ingredient-img"></div>

            <p>•{{qqq.name_ingredients}} </p>
          
          </article>
        </div>

        <div class="colonnediet">
          <p>🌱 Particularity :</p>
          <div class ="diet" v-for="diet in article.diets" :key="diet.id">
            <p> •{{diet}} </p>
          </div>
        </div>

       

          <button class="btnrecette" > <a style="color : white" v-bind:href="article.url"> See the Recipe </a> </button>

      </article>
    </div>


    <div class="proposition" v-else> 
      <div class="affich_croisde">
        <button class="ordrecrois" @click="sortByLikes(1)" v-if="listId.length > 0"> Sort in ascending order </button>
        <button class="ordredecroi" @click="sortByLikes(-1)" v-if="listId.length > 0"> Sort in descending order </button>
      </div>
      <div v-if="listId.length > 0" class="next_prec">
        <p> {{onglet_courant}} / {{listId.length/5}} </p>
        <button @click="prec()">precedent</button>
        <button @click="suivant()">next</button>
      </div>
      <article class="recettestyle" v-for="article in recettesCourantesbis" :key="article.id_recipe">
        
        <div class="headerrecette">
          <p class="titrere"> RECIPE NAME : {{article.name_recipe}} </p>
          <p>  👍 {{ article.likes}} </p>
        </div>
        <div class="recipe-img">
          <div :style="{ backgroundImage: 'url(' + article.img_recipe + ')' }" ></div>
        </div>
        
        <div class="textrecette">
          <p> ❌ MISSING INGREDIENTS : </p>
          <article v-for="kkk in article.missed_ingredients" :key="kkk.id">
        

          <p>•{{kkk.name_ingredients}} </p> 
          
          </article>

          <p> ✅ USED INGREDIENTS : </p>
          <article v-for="qqq in article.used_ingredients" :key="qqq.id">

            <p>•{{qqq.name_ingredients}} </p>
          
          </article>
        </div>
        <div class="colonnediet">
          <div class ="diet" v-for="diet in article.diets" :key="diet.id">
            <p> {{diet}} </p>
          </div>
        </div>
          <button class="btnrecette" > <a style="color : white" v-bind:href="article.url"> See the Recipe </a> </button>
      </article>
    </div>

    <div v-if="listId.length > 0">
      <p> {{onglet_courant}} / {{listId.length/5}} </p>
      <button @click="prec()">precedent</button>
      <button @click="suivant()">suivant</button>
    </div>
    <footer>
        <div class="row justify-content-center">   
          <div class="col-md-5 text-center">
            <img src="echief.png">     <strong>E-CHIEF</strong>
            <p>Come and discover our famous recipes. At E-CHIEF we will be available 24/7 for all information. Please contact us by email or phone. We wish you a pleasant visit through our website. Thank you! </p>
            <strong> Contact information </strong>
            <p>+442041345678<br>e-chief@outlook.com</p>
            <a href="" target="_blank"><i class="fab fa-facebook-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-twitter-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-linkedin"></i></a>
          </div>
          <hr class="socket">
          Copyright © All rights reserved.
        </div>
      </footer>
  </div>
</template>

<script>


module.exports = {
  props: {
    listId : { type: Array, default: []},
    recettesCourantes : { type: Array, default: []},
  },
  data () {
    return {
      editingId : 0,
      listIngredients : "",
      countMissedIngredients : 0,
      onglet_courant : 1,
      recettesCourantesbis : [],
      byIngreVar : 0,
      byQueryVar : 0,
      byCountryVar : 0
    }
  },
  async mounted () {
  },
  methods: {
    testfunction(ingredients){
      this.$emit('testfunction', ingredients)
      if(this.onglet_courant != 1){
        this.onglet_courant = 1
      }
    },
    itsTrue(id){
      if(this.editingId == id){
        return true;
      }
    },
    prec(){
      if(this.onglet_courant > 1){
        this.onglet_courant = this.onglet_courant - 1
        this.actualiser()
      }
    },
    suivant(){
      if(this.onglet_courant < this.listId.length/5){
        this.onglet_courant = this.onglet_courant + 1
        this.actualiser()
      }
    },
    actualiser(){

      if(this.onglet_courant != 1){
          this.recettesCourantesbis = []
          for(let i=(this.onglet_courant-1)*5; i<this.onglet_courant*5; i++){
            this.recettesCourantesbis.push(this.listId[i])
          }
        }
      },
      sortByLikes(x){
        if(this.onglet_courant != 1){
          this.onglet_courant = 1;
        }
        
        this.listId.sort(function compare(a, b) {
          if (a.likes < b.likes)
            return -x;
          if (a.likes > b.likes )
            return x;
          return 0;
        });
        this.$emit('changefirstpage')
        if(this.onglet_courant!=1){
          this.recettesCourantesbis = []
          for(let i=(this.onglet_courant-1)*5; i<this.onglet_courant*5; i++){
            this.recettesCourantesbis.push(this.listId[i])
          }
        }
      },
      reset(){
        this.onglet_courant = 0;
        this.recettesCourantesbis = []
        this.$emit('resetrecipes')
      },
      byIngredients(){
        if(this.byIngreVar == 0){
          this.byIngreVar = 1
        }
        if(this.byQueryVar == 1){
          this.byQueryVar = 0
        }
        if(this.byCountryVar == 1){
          this.byCountryVar = 0
        }
      },
      byQuery(){
        if(this.byIngreVar == 1){
          this.byIngreVar = 0
        }
        if(this.byQueryVar == 0){
          this.byQueryVar = 1
        }
        if(this.byCountryVar == 1){
          this.byCountryVar = 0
        }
      },
      byCountry(){
        if(this.byIngreVar == 1){
          this.byIngreVar = 0
        }
        if(this.byQueryVar == 1){
          this.byQueryVar = 0
        }
        if(this.byCountryVar == 0){
          this.byCountryVar = 1
        }
      },

  }
}
</script>

<style scoped>

  .recipe-img div {
    margin: 10px auto;
    width: 312px;
    height: 231px;
    background-size: cover;
  }

  .ingredient-img div{
    margin: 5px auto;
    width: 150px;
    height: 100px;
    background-size: cover;
  }

  .header {
    width: 100%;
    height: 670px;
    background-color: #F5D1CC;
    }
  .container {
    max-width: 1060px;
    margin: 0 auto;
    height: 300px;
    margin-top: 50px;
}
.container .cotegauche {
    width: 610px;
    margin-top: 100px;
    float: left;
}

.container .cotegauche h1 {
    font-size: 40px;
    font-weight: bold;
    margin-bottom: 30px;
}

.container .cotegauche h2 {
    font-size: 25px;

}


.container .cotegauche img {
    width: 45px;
    height: auto;
    padding-bottom: 5px;
}
.container .cotedroit {
    width: 400px;
    float: left;
}


.cotedroit form {
    display: block;
    margin-top: 0em;

}
.container .cotedroit .blocchoix
{
    background-color: white;
    -webkit-border-radius: 10px;
    border-radius: 10px;
    -webkit-box-shadow: 0 20px 35px 0 rgba(0,0,0,0.1);
    box-shadow: 0 20px 35px 0 rgba(0,0,0,0.1);
    padding: 40px;
    margin-left: 16px;
    -webkit-transition: 0.3s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    transition: 0.3s cubic-bezier(0.68, -0.55, 0.27, 1.55);
    width: 450px;
    height: 300px;
    margin-top: 100px;
}


.blocchoix p {
    font-size: 20px;
    font-weight: bold;
    text-align: center;
    margin-bottom: 35px;
}

.blocchoix select {

    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    display: block;
    width: 100%;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    border: solid 1px #444;
    outline: unset;
    background-color: #f7f7f7;
    padding: 18px;
    margin-bottom: 20px;
    font-family: 'OpenSans', sans-serif;
    font-size: 15px;
    font-weight: 600;
    color: #444;
}

.blocchoix input {
    font-family: 'OpenSans', sans-serif;
    font-size: 16px;
    font-weight: 600;
    color: white;
    padding: 20px 0;
    margin: 0;
    text-align: center;
    -webkit-border-radius: 5px;
    border-radius: 5px;
    -webkit-box-shadow: 0 10px 25px -5px rgba(250,100,132,0.85);
    box-shadow: 0 10px 25px -5px rgba(250,100,132,0.85);
    background-image: -webkit-linear-gradient(351deg, #fda59d, #fa6484);
    background-image: linear-gradient(99deg, #fda59d, #fa6484);
    cursor: pointer;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-user-select: none;
    -webkit-transition: .3s all;
    transition: .3s all;
    border: unset;
    width: 100%;
    border : none;
}

.chercher {
  width: 150px;
    height: 50px;
    border-style: none;
    background-color: #7C73BF;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
}

.searchbtn {
    width: 450px;
    height: 50px;
    border-radius: 10px;
    margin-top: 30px;
    position: relative;
    
}





.restr {
  padding-top: 50px;
}

.recettestyle {
  width: 80%;
  margin : 20px auto;
  border-radius: 15px;
  
  height: 400px;
  -webkit-box-shadow: 0px 4px 34px -10px rgba(0,0,0,0.75);
  -moz-box-shadow: 0px 4px 34px -10px rgba(0,0,0,0.75);
  box-shadow: 0px 4px 34px -10px rgba(0,0,0,0.75);  
}

.titrere {
  font-size: 20px;
  text-align: center;
  font-weight: bold;
  height: 20px;
  width: 90%;
  float: left;
}

.recipe-img {
  width: 30%;
  height: 300px;
  float: left;
  padding-top: 25px;
  padding-left: 30px;

}



.textrecette {
  width: 25%;
  float: left;
  padding-top: 30px;
  height: 300px;
    padding-left: 30px;

}

.btnrecette {
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #7C73BF;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 100px;
    cursor: pointer;
    position: relative;
}

.typere {
  text-align: center;
  font-size: 30px;
  padding-top: 20px;
  margin-left: 40px;
}

.btning {
    margin-left: 480px;
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #7C73BF;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
}

.btnquery {
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #36817F;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
}

.btncountry {
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #FF3562;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
}

.btnreset {
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #C6C7C4;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
    margin-left: 643px;
}

.diet {
  width: 100px;
}

.headerrecette {
  padding-top: 17px;
}

.colonnediet {
  width: 200px;
  max-height: 350px;
  float: left;
  padding-top: 30px;
}

.btnrecette {
    width: 200px;
    height: 60px;
    border-style: none;
    background-color: #7C73BF;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 100px;
    cursor: pointer;
    position: relative;
    text-decoration: none;
    

}


.proposition {
  padding-top: 30px;
  padding-left: 100px;
  width : 80%;
  margin: auto;
  border : 2px solid red;
}


.searchbtn {
    width: 450px;
    height: 50px;
    border-radius: 10px;
    margin-top: 30px;
    position: relative;
    
}

.btning2 {
  margin-left: 30px;
    width: 150px;
    height: 50px;
    border-style: none;
    background-color: #7C73BF;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    margin-right: 10px;
    margin-top: 15px;
    cursor: pointer;
    position: relative;
}

.ordrecrois {
    width: 200px;
    height: 50px;
    border-style: none;
    background-color: #1B998B;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    cursor: pointer;
    position: relative;
}

.ordredecroi {
    width: 200px;
    height: 50px;
    border-style: none;
    background-color: #D7263D;
    color: white;
    font-size: 13px;
    border-radius: 8px;
    cursor: pointer;
    position: relative;
}

.diet p {
  margin: 0;
}

.affich_croisde{
  width: 30%;
  margin: 35px auto;
  display: flex;
  justify-content: space-around;
}

 .next_prec{
   width : 25%;
   display: flex;
   margin : auto;
   justify-content: space-between;
 }

 .search_ingredients{
   width : 70%;
   margin : 20px auto;
 }

 .search_ingredients div{
   display: inline-block;
   text-align: center;
 }


footer{
  background-color:#F5D1CC;
  color:black;
  padding:2rem 0 2rem;
  margin-top:1rem;
}

footer img {
  height:4rem;
  margin:1.5rem 0;
}

footer a {
  color:#FF69B4;
}

footer svg.svg-inline--fa {
  font-size:2rem;
  margin:1.2rem .5rem 0 0;
}

footer svg.svg-inline--fa:hover {
  color:#FF1493;
}
hr.socket{
  width:100%;
  border-top:.2rem solid #FF1493;
  margin-top:3rem;
}
</style>