# Install

`npm install`

# Run

`npm start`